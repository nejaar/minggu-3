﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Data Kosong", MsgBoxStyle.Critical, "Error")
            TextBox1.Focus()
        ElseIf TextBox1.Text = "admin" And TextBox2.Text = "12345" Then
            Form2.Show()
            Me.Hide()
        Else
            MsgBox("Username/Password Salah", MsgBoxStyle.Critical, "Error")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox1.Focus()
        End If
    End Sub
End Class
